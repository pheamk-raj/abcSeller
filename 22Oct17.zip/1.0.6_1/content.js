﻿
// Find the search textbox that appears on most amazon pages
var textbox = document.getElementById('twotabsearchtextbox');

// If the search textbox is found
if (textbox) {
    // Set focus to it, allowing the user to immediately begin typing their search criteria.
    textbox.focus();
}